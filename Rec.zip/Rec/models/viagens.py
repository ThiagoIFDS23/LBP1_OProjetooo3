def add_Viagem(viagens, id, destino, data, descricao, nota):
    viagens.append({
        "id": id,
        "destino": destino,
        "data": data,
        "descricao": descricao,
        "nota": nota
        })